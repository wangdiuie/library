<template>
	<view class="">
		我的
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		method:{
			
		}
 }		
</script>

<style scoped>

</style>
