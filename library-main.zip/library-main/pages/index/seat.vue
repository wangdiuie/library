<template>
	<view class="container">
		<!-- ------ -->
		<view class="select_date" @click="date">
			<view class="left">使用日期</view> <view class="right"> 
			<text>{{chooseDate}}
			</text>
			<image :src="arrow" mode=""></image>
			</view>
		</view>
		<!-- ------ -->
		<view class="select_date" @click="time">
			<view class="left">开始时间</view> <view class="right">
			<text>{{startTime}}</text>
			<image :src="arrow" mode=""></image></view>
		</view>
		<!-- ------ -->
		<view class="select_date" @click="use">
			<view class="left">使用时长</view> <view class="right">
			<text>{{useTime}}</text>
			<image :src="arrow" mode=""></image></view>
		</view>
		<!-- ------- -->
		<view class="select_date" @click="openChooseModal">
			<view class="left">使用人数</view> <view class="right"><text>{{people}}人</text><image :src="arrow" mode=""></image></view>
		</view>
		 <view class="start_seat" @click="startSeat">
		 	  开始选座
		 </view>
		<!-- 这里是使用日期弹出层 -->
		<view class="shade" v-if="date_shade" @click="this.date_shade=false">
			<view class="date" >
				<view class="today" @click="chooseDay(0)">
					<text>{{month}}月{{day}}日</text><text>-周{{week==0?7:week}}</text>
				</view>
				<view class="tomorrow" @click="chooseDay(1)">
					<text>{{tomorrow}}日</text><text>-周{{week==0?1:week+1}}</text>
				</view>
			</view>
		</view>
		<!-- 使用日期弹出层结束 -->
		
		
		<!-- 开始时间弹出层 -->
		<view class="shade" v-if="time_shade" @click="this.time_shade=false">
			<view class="time" >
				<view class="time1" v-for="(item,index) in startTime_choose" :key="index" @click="chooseStartTime(index)">
					<text>{{item}}</text> 
				</view>
				<view class="time2" @click="this.startTime='20:00'">
					<text>20:00</text>
				</view>
			</view>
		</view>
		<!-- 开始时间弹出层结束 -->
		
		<!-- 使用时长弹出层 -->
		<view class="shade" v-if="use_shade" @click="this.use_shade=false">
			<view class="use" >
				<view class="use1" v-for="(item,index) in useTime_choose" :key="index" @click="chooseUseTime(index)">
					<text>{{item}}</text> 
				</view>
				<view class="use2" @click="this.useTime='8小时'">
					<text>8</text>
				</view>
			</view>
		</view>
		<!-- 使用时长弹出层结束 -->
		
	</view>
</template>

<script>
	import {ajax} from '../../static/ajax/ajax.js'
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniPopupMessage from '@/components/uni-popup/uni-popup-message.vue'
	import uniPopupDialog from '@/components/uni-popup/uni-popup-dialog.vue'
	import {getDay} from '../../static/function/getday.js'
	export default {
	   components: {
		        uniPopup,
		        uniPopupMessage,
		        uniPopupDialog
		},
		data() {
			return {
				account:'',
				arrow:'../../static/img/arrow.svg',
				month:'', //几月
				day:'',  //几日
				week:'',  //星期几
				people:'1',   //使用人数几人
				date_shade:false,  //使用日期弹窗遮罩
				time_shade:false,  //开始时间弹窗遮罩
				tomorrow: '',
				chooseDate: '',  //使用日期
				startTime_choose:['7:00','8:00','9:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00','18:00','19:00'],
				startTime:'7:00',   //开始时间
				use_shade:false,  //使用时长弹窗遮罩
				useTime:'1小时',   //使用时长
				useTime_choose:['1','2','3','4','5','6','7']			
			}
		},
		methods: {
			date(){
				this.date_shade=true
			},
			time(){
				this.time_shade=true
			},
			use(){
				this.use_shade=true
			},
			openChooseModal(){
				let that=this
				uni.showActionSheet({
				    itemList: ['1', '2', '3','4'],
				    success: function (res) {
							that.people=res.tapIndex + 1
							  console.log(res)
				        console.log('选中了第' + (res.tapIndex + 1) + '个按钮');
				    }
				})
			},
			chooseDay(i) {
				const {month,day,week,tomorrow} = this
				if(i==0){
					this.chooseDate = month+"月"+day+"日-周"+(week==0?7:week)
				}else{
					this.chooseDate = tomorrow+"日-周"+(week==0?1:week+1)
				}
			},
			chooseStartTime(index){
				this.startTime=this.startTime_choose[index]
			},
			chooseUseTime(index){
				this.useTime=this.useTime_choose[index]+'小时'
			},
		async	startSeat(){
			console.log(this.account)
			console.log(this.chooseDate)
			console.log(this.startTime)
			console.log(parseInt(this.useTime.slice(0,1)))
			console.log(parseInt(this.people))
	 const res = await ajax({
				     url:'/seat',
					 data: {
					 account:this.account,
					 date:this.chooseDate,
					 startTime:this.startTime,
					 useTime:parseInt(this.useTime.slice(0,1)),
					 userNum:parseInt(this.people)
					}
			   })
					   
		   } 
	    },
		onLoad(){
			let that=this
			let date=new Date()
			this.day=date.getDate().toString().length==1?'0'+date.getDate():date.getDate()
			this.month=date.getMonth()+1
			this.week=date.getDay()
			this.tomorrow=getDay(1,'月').slice(5)
			this.chooseDate = this.month+"月"+this.day+"日-周"+(this.week==0?7:this.week)
			uni.getStorage({
			    key: 'account',
			    success: function (res) {
			        that.account=res.data
			    }
			})
		}
 }		
</script>

<style lang="less" scoped>
.container{
	.select_date{
		border-bottom: 1rpx solid #C0C0C0;
		height: 100rpx;
		font-size: 30rpx;
		display: flex;
		align-items: center;
		padding: 0 30rpx;
		.left{
			flex: 1;
		}
		.right{
			flex: 1;
			text-align: right;
			image{
				margin-left: 30rpx;
				width: 20rpx;
				height: 20rpx;
			}
		}
	}
	
	.shade{
		background-color: rgba(0,0,0,0.5);
		height: 100vh;
		width: 100vw;
		position: absolute;
		top: 0;
		left: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		.date{
			height: 200rpx;
			width: 600rpx;
			display: flex;
			flex-direction: column;
			background-color: #fff;
			padding: 30rpx;
			border-radius: 30rpx;
			.today{
				flex:1;
				padding:0 20rpx; 
				border-bottom: 1px solid #C0C0C0;
				display: flex;
				align-items: center;
			}
			.tomorrow{
				flex:1;
				padding:0 20rpx; 
				display: flex;
				align-items: center;
			}
		}
		.time{
			height: 960rpx;
			width: 600rpx;
			display: flex;
			flex-direction: column;
			background-color: #fff;
			padding: 30rpx;
			border-radius: 30rpx;
			overflow-y: scroll;
			.time1{
				height: 100rpx;
				line-height: 100rpx;
				padding:0 20rpx; 
				border-bottom: 1px solid #C0C0C0;
				text-align: center;
			}
			.time2{
				height: 100rpx;
				line-height: 100rpx;
				padding:0 20rpx; 
				text-align: center;
			 }
		}	
		.use{
			height: 800rpx;
			width: 600rpx;
			display: flex;
			flex-direction: column;
			background-color: #fff;
			padding: 30rpx;
			border-radius: 30rpx;
			overflow-y: scroll;
			.use1{
				height: 100rpx;
				line-height: 100rpx;
				padding:0 20rpx; 
				border-bottom: 1px solid #C0C0C0;
				text-align: center;
			}
			.use2{
				height: 100rpx;
				line-height:100rpx;
				padding:0 20rpx; 
				text-align: center;
			}	
		}	
	}	
	.start_seat{
		width: 60%;
		line-height: 100rpx;
		font-size: 50rpx;
		background-color: #0d7dbd;
		color: #fff;
		border-radius: 20rpx;
		height: 100rpx;
		text-align: center;
		position: fixed;
		bottom: 20rpx;
		left: 20%;
	}
}
</style>