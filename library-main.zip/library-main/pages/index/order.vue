<template>
	<view class="">
		预约
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		method:{
			
		}
 }		
</script>

<style scoped>

</style>